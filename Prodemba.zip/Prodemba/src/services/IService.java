/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import entities.Consultationpatient;
import entities.Prestationpatient;
import entities.Patient;
import entities.Rendez_vous;
import entities.User;
import java.util.List;



public interface IService {

    
      //Ajout,modification,suppression boolean
        //true ajout correct
       // false Erreur
    
    
    /*Gerer Pattient*/
    public int addPatient(Patient patient);
    public boolean updatePatient(Patient patient);
    public boolean deletePatient(int id);
    public List<Patient> searchAllPatient();
    public Patient searchOnePatient(int id);
    
    /*Gerer RV*/
    public int addRendez_vous(Rendez_vous Rendez_vous);
    public int addConsultationpatient(Consultationpatient Consultationpatient);
    public int addPrestationpatient(Prestationpatient Prestationpatient);

    public boolean updateRendez_vous(Rendez_vous Rendez_vous);
    public boolean deleteRendez_vous(int id);
    public List<Rendez_vous> searchAllRendez_vous();
    public Rendez_vous searchOneRendez_vous(int id);
      
     
    /*Lister RV*/
    public List<Rendez_vous> showAllRendez_vous();
    public List<Patient> searchSecretaireByResponsablePrestation(String nci,String Date);
 
    
    
      
/*Se connecter */
    public User login(String login,String password);
      

    
    
}
