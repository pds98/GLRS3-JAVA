/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

import entities.Consultationpatient;
import entities.Patient;
import entities.Rendez_vous;
import entities.User;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import services.Service;

/**
 * FXML Controller class
 *
 * @author Lenovo
 */
public class ConsultationController implements Initializable {

    @FXML
    private Text txtError;
        @FXML
    private TextField txtnom;
            @FXML
    private TextField txtprenom;
        private User user;
    private final Service service = new Service();
    private static ConsultationController ctrl;
    
    private Rendez_vous Rendez_vous;
    @FXML
    private ComboBox<String> handletypecons;
    
    //combobox
    private void loadComboBoxTypeRdv(ComboBox<String> cboTypeRdv){
        cboTypeRdv.getItems().add("Veuillez Choisir");
        cboTypeRdv.getItems().add("Ophtalmologie");
        cboTypeRdv.getItems().add("Pneumologue");
        cboTypeRdv.getItems().add("Dentiste");
        cboTypeRdv.getItems().add("Orthopediste");
        cboTypeRdv.getSelectionModel().selectFirst();
    }
 
    
    public User getUser(){
        return user;
    }
    
     public static ConsultationController getCtrl(){
        return ctrl;
    }
    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
         // TODO
         txtError.setVisible(false);
         ctrl=this;
         loadComboBoxTypeRdv(handletypecons);
        
    }    


    @FXML
    private void handlevalider(ActionEvent event) {
        String login = txtnom.getText().trim();
        String inf = txtprenom.getText().trim();
        String libelle="Consultation";
        String typeConsultation= handletypecons.getSelectionModel().getSelectedItem();
        
        if(login.isEmpty() || inf.isEmpty())
        {
          txtError.setText("le nom ou le prenom est Obligatoire");
          txtError.setVisible(true);
        }
        else{
               
              //insertion des éléments
              Consultationpatient consp=new Consultationpatient();
              consp.setNom(login);
              consp.setPrenom(inf);
              consp.setLibelle(libelle);
              consp.setConsultation_demander(typeConsultation);
              service.addConsultationpatient(consp);
        
        
              //Cache la fénétre de connexion
              this.txtError.getScene().getWindow().hide();
              AnchorPane root = null;
              String role = ConnexionController.getCtrl().getUser().getRole();
              System.out.print(role);
              
              try {
                
                  root = FXMLLoader.load(getClass().getResource("/views/v_patient.fxml"));
                  Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
                  //popup
                  JOptionPane.showMessageDialog(null,"INSCRIPTION SUCCESSFULL");
                  
                  
                  
              } catch (IOException ex) {
                  Logger.getLogger(ConnexionController.class.getName()).log(Level.SEVERE, null, ex);
              }
                            this.txtError.getScene().getWindow().hide();

          
        }
        
        
    }
    
 

    @FXML
    private void handleclear(ActionEvent event) {
        txtnom.clear();
        txtprenom.clear();
        txtError.setVisible(true);
    }

    
}
