/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entities.*;
import entities.Consultationpatient;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lenovo
 */
public class ConsultationPatientDao implements IDao<Consultationpatient>{
    
            //création d'un objet  database dans patient

    private final DataBase database = new DataBase();
     //requete SQL pour un INSERT de patient
    private final String SQL_INSERT= "INSERT INTO `rendez_vous`(  `libelle`, `nom`, `prenom`, `consultation_demander`)"
            + " VALUES (?,?,?,?)";
   //requete SQL pour une Update
    private final String SQL_UPDATE="SELECT * FROM consultationpatient WHERE ";
    private final String SQL_SELECT_consultationpatient_BY_ID = "SELECT * FROM consultationpatient consp, rendez_vous rv, "
            + "WHERE id = ";
    
   //code d'nsertion par etape bien def
    @Override
    public int insert(Consultationpatient consp) {
        int id=0;
        database.openConnexion();
        //chargement de la base de donnee et des requetes
        database.initPrepareStatement(SQL_INSERT);
        try {
            
            database.getPs().setString(1, consp.getLibelle());
            database.getPs().setString(2, consp.getNom());
            database.getPs().setString(3, consp.getPrenom());
            database.getPs().setString(4, consp.getConsultation_demander());


            database.executeUpdate(SQL_INSERT);
            ResultSet rs= database.getPs().getGeneratedKeys();
            if(rs.next()){
                id=rs.getInt(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ConsultationPatientDao.class.getName()).log(Level.SEVERE, null, ex);
        }return id;
    }
    
   

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Consultationpatient> findAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

 
    @Override
    public int update(Consultationpatient ogj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
     @Override
    public Consultationpatient findById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
  
    
}
