/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entities.*;
import entities.Prestationpatient;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lenovo
 */
public class PrestationPatientDao implements IDao<Prestationpatient>{
    
            //création d'un objet  database dans patient

    private final DataBase database = new DataBase();
     //requete SQL pour un INSERT de patient
    private final String SQL_INSERT= "INSERT INTO `rendez_vous`(  `libelle`, `nom`, `prenom`, `prestation_demander`)"
            + " VALUES (?,?,?,?)";
   //requete SQL pour une Update
    private final String SQL_UPDATE="SELECT * FROM prestationpatient WHERE ";
    private final String SQL_SELECT_prestationpatient_BY_ID = "SELECT * FROM prestationpatient presp, rendez_vous rv, "
            + "WHERE id = ";
    
   //code d'nsertion par etape bien def
    @Override
    public int insert(Prestationpatient presp) {
        int id=0;
        database.openConnexion();
        //chargement de la base de donnee et des requetes
        database.initPrepareStatement(SQL_INSERT);
        try {
            
            database.getPs().setString(1, presp.getLibelle());
            database.getPs().setString(2, presp.getNom());
            database.getPs().setString(3, presp.getPrenom());
            database.getPs().setString(4, presp.getPrestation_demander());


            database.executeUpdate(SQL_INSERT);
            ResultSet rs= database.getPs().getGeneratedKeys();
            if(rs.next()){
                id=rs.getInt(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(PrestationPatientDao.class.getName()).log(Level.SEVERE, null, ex);
        }return id;
    }
    
   

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Prestationpatient> findAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

 
    @Override
    public int update(Prestationpatient ogj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
     @Override
    public Prestationpatient findById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
  
    
}
