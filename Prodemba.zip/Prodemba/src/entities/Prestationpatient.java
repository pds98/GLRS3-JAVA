/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.Date;
import java.util.List;

/**
 *
 * @author Lenovo
 */
public class Prestationpatient {
         protected int id;
        protected Date date;
        protected String libelle;
        protected String nom;
        protected String prenom;
        protected int codeprestation;
        protected Prestationpatient prestation;
        protected  List<Consultationpatient> consultations;
        protected  String prestation_demander;

    public Prestationpatient() {
    }

    public Prestationpatient(int id, Date date, String libelle, String nom, String prenom, int codeprestation, Prestationpatient prestation, List<Consultationpatient> consultations, String prestation_demander) {
        this.id = id;
        this.date = date;
        this.libelle = libelle;
        this.nom = nom;
        this.prenom = prenom;
        this.codeprestation = codeprestation;
        this.prestation = prestation;
        this.consultations = consultations;
        this.prestation_demander = prestation_demander;
    }

    public Prestationpatient(Date date, String libelle, String nom, String prenom, int codeprestation, Prestationpatient prestation, List<Consultationpatient> consultations, String prestation_demander) {
        this.date = date;
        this.libelle = libelle;
        this.nom = nom;
        this.prenom = prenom;
        this.codeprestation = codeprestation;
        this.prestation = prestation;
        this.consultations = consultations;
        this.prestation_demander = prestation_demander;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public int getCodeprestation() {
        return codeprestation;
    }

    public void setCodeprestation(int codeprestation) {
        this.codeprestation = codeprestation;
    }

    public Prestationpatient getPrestation() {
        return prestation;
    }

    public void setPrestation(Prestationpatient prestation) {
        this.prestation = prestation;
    }

  

    public String getPrestation_demander() {
        return prestation_demander;
    }

    public void setPrestation_demander(String prestation_demander) {
        this.prestation_demander = prestation_demander;
    }

    
}