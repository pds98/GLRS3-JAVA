/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.List;

/**
 *
 * @author Lenovo
 */
public class Medecin extends User {
    private int statut;
    
    public List<Consultation> consultation;
    
    public  Medecin() {
        
    }

    public Medecin(int statut, int id, String nom, String penom, String login, String password, String role, String tel) {
        super(id, nom, penom, login, password, role,tel);
        this.statut = statut;
    }

    public Medecin(int statut, String nom, String penom, String login, String password, String role, String tel) {
        super(nom, penom, login, password, role, tel);
        this.statut = statut;
    }

    public int getStatut() {
        return statut;
    }

    public void setStatut(int statut) {
        this.statut = statut;
    }

    public Medecin(int statut) {
        this.statut = statut;
    }

    public void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
