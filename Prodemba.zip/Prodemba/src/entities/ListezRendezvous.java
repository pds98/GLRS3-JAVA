/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.List;

/**
 *
 * @author Lenovo
 */
public class ListezRendezvous {
        protected int id;
        protected String libelle;
        protected String nom;
        protected String prenom;
        protected  List<Prestationpatient> prestations;
        protected  List<Consultationpatient> consultations;
    protected List<ListezRendezvous> listezRendezvous;

    public ListezRendezvous() {
    }

    public ListezRendezvous(int id, String libelle, String nom, String prenom, List<Prestationpatient> prestations, List<Consultationpatient> consultations) {
        this.id = id;
        this.libelle = libelle;
        this.nom = nom;
        this.prenom = prenom;
        this.prestations = prestations;
        this.consultations = consultations;
    }

    public ListezRendezvous(String libelle, String nom, String prenom, List<Prestationpatient> prestations, List<Consultationpatient> consultations) {
        this.libelle = libelle;
        this.nom = nom;
        this.prenom = prenom;
        this.prestations = prestations;
        this.consultations = consultations;
    }

    public ListezRendezvous(int id, String libelle, String nom, String prenom) {
        this.id=id;
        this.libelle=libelle;
        this.nom = nom;
        this.prenom = prenom;
    }

    public ListezRendezvous(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public ListezRendezvous(String text) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public List<Prestationpatient> getPrestations() {
        return prestations;
    }

    public void setPrestations(List<Prestationpatient> prestations) {
        this.prestations = prestations;
    }

    public List<Consultationpatient> getConsultations() {
        return consultations;
    }

    public void setConsultations(List<Consultationpatient> consultations) {
        this.consultations = consultations;
    }

    public String getConsultaion_demander() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getPrestation_demander() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void add(ListezRendezvous lrv) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
