/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.List;

/**
 *
 * @author Lenovo
 */
public class Secretaire extends User {
    
    public List<Rendez_vous> rendez_vous;
    
    
    
    
    
    public Secretaire (){
        
    }

    public Secretaire(String nom, String prenom, String login, String password, String role, String tel) {
        super(nom, prenom, login, password, role, tel);
    }

    public Secretaire(int id, String nom, String prenom, String login, String password, String role, String tel) {
        super(id, nom, prenom, login, password, role, tel);
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPenom(String penom) {
        this.prenom = prenom;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
    
}
